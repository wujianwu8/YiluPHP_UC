var language = {
    application_status_1: "Normal",
    complaint_status_1: "Processing"
};
